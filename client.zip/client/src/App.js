import logo from './logo.svg';
import './App.css';
import Home from './pages/Home';


function App() {
  console.log("")
  return (
   <>
   <Home />
   </>
  );
}

export default App;
