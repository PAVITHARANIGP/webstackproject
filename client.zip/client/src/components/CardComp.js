import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';

function CardComp({ dt }) {
  // console.log(dt)
  const handleSaveChanges = () => {
    var titlev = document.getElementById('title').value;
    var authorv = document.getElementById('author').value;
    var descv = document.getElementById('desc').value;
    var imagev = document.getElementById('image').value;
    
    console.log("title",titlev)

    if (titlev.length < 3) {
      window.alert('Enter a title')
    } else if (!authorv) {
      window.alert("Enter author's name")
    } else if (!descv) {
      window.alert("Enter description")
    } else if (!imagev) {
      window.alert("Enter image url")
    } else {
      // Create a data object with the form values
      const postData = {
        title: title,
        author: author,
        imgUrl: imgUrl,
        description: desc,
        type: dt.type,
      };


      // Use Axios to send a POST request to your API
      axios
        .post(`http://localhost:8000/update-news/${dt.id}`, postData)
        .then((response) => {
          console.log('Post successful:', response);
          handleClose(); // Close the modal after a successful post
        })
        .catch((error) => {
          console.error('Error posting data:', error);
          // You can handle errors here, e.g., show an error message to the user
        });
      handleClose()
      window.location.reload()
    }

  };
  const handleDelete = () => {

    axios
      .delete(`http://localhost:8000/delete-news/${dt.id}`)
      .then((response) => {
        console.log('Delete successful:', response);
        handleClose(); // Close the modal after a successful post
      })
      .catch((error) => {
        console.error('Error posting data:', error);
        // You can handle errors here, e.g., show an error message to the user
      });
    handleClose()

    window.location.reload()
  }

  const [imgUrl, setImgUrl] = useState("")
  const [title, setTitle] = useState("")
  const [desc, setDesc] = useState("")
  const [author, setAuthor] = useState("")

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>

      <Card className='card'>
        <Card.Img className='card-img' variant="top" src={dt.imgURL} />
        <Card.Body>
          <Card.Title>{dt.title}</Card.Title>
          <Card.Subtitle>{dt.author}</Card.Subtitle>
          <Card.Text>
            {dt.description}
          </Card.Text>
          <button className="card-button" onClick={handleShow}>
            Edit
          </button>
          {'      '}
          <button className='card-button' variant="danger" onClick={handleDelete}>
            Delete
          </button>



          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Edit News</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>Title</Form.Label>
                  <Form.Control
                    placeholder={dt.title}
                    id='title'
                    onChange={(e) => setTitle(e.target.value)}
                    type="text"
                    autoFocus
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>Author</Form.Label>
                  <input className='form-control'
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder={dt.author}
                    type="text"
                    autoFocus
                    id='author'
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                  <Form.Label>ImageUrl</Form.Label>

                  <input className='form-control'
                    onChange={(e) => setImgUrl(e.target.value)}
                    type="text"
                    placeholder={dt.imgURL}
                    autoFocus
                    id='image'
                  />
                </Form.Group>
                <Form.Group
                  className="mb-3"
                  controlId="exampleForm.ControlTextarea1"
                >
                  <Form.Label>Description</Form.Label>
                  <input className='form-control' id='desc' as="textarea" rows={3} placeholder={dt.description} onChange={(e) => setDesc(e.target.value)} />
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <button className='card-button' variant="secondary" onClick={handleClose}>
                Close
              </button>
              <button className='card-button' variant="primary" onClick={handleSaveChanges}>
                Save Changes
              </button>
            </Modal.Footer>
          </Modal>
        </Card.Body>
      </Card>
    </>
  );
}

export default CardComp;