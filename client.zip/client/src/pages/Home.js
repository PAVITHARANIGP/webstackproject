import React, { useEffect, useState } from 'react'
import CardComp from '../components/CardComp'
import axios from 'axios';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import AddBtn from '../components/AddBtn';
import Spinner from 'react-bootstrap/Spinner';
import logo from '../pages/logo.jpeg'

const Home = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {

    // Define an async function
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8000/get-all-news');
        setData(response.data);
        setLoading(false);
        // console.log(data)
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    // Call the async function
    fetchData();
  }, []);

  const handleClick = async (filType) => {
    console.log(filType)
    const response = await axios.get('http://localhost:8000/get-all-news');
    if (filType === "") {
      window.location.reload()
    }
    const sportsData = response.data.filter(item => item.type === filType);
    setData(sportsData);

    setLoading(false);
  };
  return (
    <>
      {/* <Navbar expand="lg" className="bg-body-tertiary">
        <Container>
          <Navbar.Brand href="#home"><img src='logo.jpeg' /></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link onClick={()=>handleClick("")}>Home</Nav.Link>
              <Nav.Link onClick={()=>handleClick("Business News")}>Business News</Nav.Link>
              <Nav.Link onClick={()=>handleClick("Sports News")}>Sports News</Nav.Link>
              <Nav.Link onClick={()=>handleClick("Entertainment News")}>Entertainment News</Nav.Link>
              <Nav.Link onClick={()=>handleClick("Politics News")}>Politics News</Nav.Link>
              <AddBtn />
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar> */}
      <div className='home_main'>

      <nav className='navBar'>
        <div className='logo'>
          <img src={logo} alt="logo" />
        </div>
        <div className='links'>
          <Nav.Link className='link-item' onClick={() => handleClick("")}>Home</Nav.Link>
          <Nav.Link className='link-item' onClick={() => handleClick("Business News")}>Business </Nav.Link>
          <Nav.Link className='link-item' onClick={() => handleClick("Sports News")}>Sports </Nav.Link>
          <Nav.Link className='link-item' onClick={() => handleClick("Entertainment News")}>Entertainment </Nav.Link>
          <Nav.Link className='link-item' onClick={() => handleClick("Politics News")}>Politics </Nav.Link>
        </div>
        <div className='addBtn'>
          <AddBtn/>
        </div>

      </nav>
      <div className='homeSection'>
        {/* <Carousel /> */}
        <div className='flexBox'>
          {
            data.length > 0 ? data.map((dts) => (

              <CardComp key={dts.id} dt={dts} />
            )) : (
              <div className='center'>
                <Spinner animation="grow" variant="secondary" />
              </div>
            )
          }
        </div>
      </div>
      </div>

    </>
  )
}

export default Home
